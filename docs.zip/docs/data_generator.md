

## 学習データ作成

物体検知、姿勢推定する対象の物体を Blender で定義し、物体の「見え方」を意図的／ランダムに変える Ptyhon スクリプトで学習データを作成。
<img src="image/data_generate_flow.png" width="700">

**作成学習データ：画像と Ground Truth（「答え」「教師データ」）**
<img src="image/dataset.png" width="700">

**Ground Truth (pose.csv)**
|filename|yaw_deg|pitch_deg|roll_deg|
|---|---|---|---|
|image_000.png|-6.8996282153045705|-5.025345867321963|-10.525019445437653|
|image_001.png|8.35276711483948|-0.9609561851165367|-12.900560003411714|
|image_002.png|2.9578660068104767|-13.931309636977517|-2.3784254970793484|
|image_003.png|-6.533533960073385|14.206854692517197|-6.916011003005078|
|image_004.png|-26.132204803660922|-19.927622466748733|7.514318912517197|
|image_005.png|29.058151928394764|11.511442932146942|5.433422204970057|
|image_006.png|-22.91790364338372|0.902442523878527|4.8690625817340205|
|image_007.png|-14.64621617988332|12.988037052180182|-0.7730591877584168|
|image_008.png|2.20636145194689|14.612882884443422|14.89382783621533|
|image_009.png|9.163361501914707|-15.338461980589123|-8.361533136450117|

**image_000.png**
<img src="image/cube_000.png" width="300">

•	Yaw = -6.89°（Z軸でプラス）
•	Pitch = -5.02°（Y軸でマイナス）
•	Roll = -10.52°（X軸でマイナス）

**image_009.png**
<img src="image/cube_009.png" width="300">

•	Yaw = 9.16°
•	Pitch = -15.33°
•	Roll = -8.36°


**文献：[Domain Randomization for Transferring Deep Neural Networks from
Simulation to the Real World](https://arxiv.org/pdf/1703.06907)**

<img src="image/paper_Domain_Randomization.png" width="400">

---
## 物体の位置と姿勢の算出：solvePnP

**solvePnP とは**
•	「2D画像と既知の3D情報から、物体の位置と姿勢（Pose）を計算するアルゴリズム」
•	カメラで写った点と、実際の3D座標の対応関係を利用

**仕組み**
<img src="image/solvePnP.jpg" width="400">
図：[Perspective-n-Point (PnP) pose computation](https://docs.opencv.org/3.4/d5/d1f/calib3d_solvePnP.html)

•	キーポイント（3D）と画像上の位置（2D）をマッチング
•	カメラの内部パラメータ（焦点距離など）を元に 姿勢を逆算

**solvePnP への入力**
|項目|内容|
|---|---|
|カメラキャリブレーション|焦点距離、レンズ歪みなど|
|3Dキーポイント|物体上の「キーポイント」の3D座標|
|2D画像上のキーポイント|検出物体の「キーポイント」の2D座標|


前述の「3Dキューブ」を使った例：
<img src="image/pnp_cube.png" width="400">

**メリット**
•	軽量＆高速（ラズパイでも動作可）
•	精度はキーポイントの配置次第
•	単眼カメラでOK、再現性高い

**精度に影響する要因**
•	カメラキャリブレーションの精度
•	キーポイントの選び方（均等配置が望ましい）
•	画像に対する認識精度（2D側の誤差）
