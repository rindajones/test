import bpy
import math
import random
import csv
from mathutils import Euler

output_dir = "output"
image_res = 512
num_images = 10

csv_path = f"{output_dir}/poses.csv"
with open(csv_path, "w", newline="") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["filename", "yaw_deg", "pitch_deg", "roll_deg"])

    for i in range(num_images):
        yaw = random.uniform(-30, 30)
        pitch = random.uniform(-20, 20)
        roll = random.uniform(-20, 20)

        bpy.data.objects["ColorCube"].rotation_euler = Euler((
            math.radians(pitch),
            math.radians(roll),
            math.radians(yaw)
        ), 'XYZ')

        filename = f"image_{i:03}.png"
        bpy.context.scene.render.filepath = f"{output_dir}/{filename}"
        bpy.context.scene.render.image_settings.file_format = 'PNG'
        bpy.context.scene.render.image_settings.color_mode = 'RGBA'
        bpy.context.scene.render.resolution_x = image_res
        bpy.context.scene.render.resolution_y = image_res
        bpy.context.scene.render.film_transparent = True

        bpy.ops.render.render(write_still=True)
        writer.writerow([filename, yaw, pitch, roll])

