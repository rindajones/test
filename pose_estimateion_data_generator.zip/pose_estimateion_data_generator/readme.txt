cube_v0.blend: ColorCube without camera & light
cube_v001.blend: ColorCube with camera & light

cube_pose_generator
 |- cube_pose_generator.blend  # Same as cube_v001.blend
 |- generate_dataset.py
 |- output         # Learning data for pose estimation
    |- *.png       # Images
    |- pose.csv    # yaw, pitch, roll

# To generate dataset
$ blender -b cube_pose_generator.blend --python generate_dataset.py

