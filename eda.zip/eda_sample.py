import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 仮のサンプル時系列データを作成（5種類のセンサ）
np.random.seed(42)
time_index = pd.date_range(start="2024-01-01", periods=300, freq="T")

df = pd.DataFrame({
    "current": np.random.normal(loc=5, scale=0.5, size=300),
    "rpm": np.random.normal(loc=1500, scale=50, size=300),
    "sound": np.random.normal(loc=60, scale=10, size=300),
    "vibration": np.random.normal(loc=0.2, scale=0.05, size=300),
    "temperature": np.random.normal(loc=40, scale=1, size=300),
}, index=time_index)

# sound と vibration を相関させる
df['sound'] = df['vibration'] * 300 + np.random.normal(0, 2, size=len(df))

# 異常区間を挿入（仮に50〜70分）
df.iloc[50:70, 0] += 2   # current spike
df.iloc[50:70, 1] -= 200 # rpm drop
df.iloc[50:70, 3] += 0.3 # vibration spike

# 相関ヒートマップ
corr_fig, corr_ax = plt.subplots(figsize=(6, 4))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm', ax=corr_ax)
corr_ax.set_title("Sensor Correlation Heatmap")
plt.savefig('./image/sample_corheat.png')


# 折れ線プロット
line_fig, line_ax = plt.subplots(5, 1, figsize=(12, 8), sharex=True)
for i, column in enumerate(df.columns):
    line_ax[i].plot(df.index, df[column])
    line_ax[i].set_ylabel(column)
    line_ax[i].axvspan(df.index[50], df.index[70], color='red', alpha=0.2)
line_ax[-1].set_xlabel("Time")
line_ax[0].set_title("Sensor Time Series (with anomaly range)")
plt.savefig('./image/sample_line.png')
plt.show()

# 移動統計（rolling mean/std）プロット（例: vibration）
rolling_fig, rolling_ax = plt.subplots(figsize=(10, 4))
df['vibration'].rolling(window=10).mean().plot(ax=rolling_ax, label='Rolling Mean')
df['vibration'].rolling(window=10).std().plot(ax=rolling_ax, label='Rolling Std')
rolling_ax.axvspan(df.index[50], df.index[70], color='red', alpha=0.2)
rolling_ax.set_title("Vibration Sensor - Moving Stats")
rolling_ax.legend()
plt.savefig('./image/sample_rolling.png')
plt.show()

# 散布図（sound vs vibration）
scatter_fig, scatter_ax = plt.subplots(figsize=(6, 4))
scatter_ax.scatter(df['sound'], df['vibration'], c='gray', alpha=0.6)
scatter_ax.set_xlabel("Sound")
scatter_ax.set_ylabel("Vibration")
scatter_ax.set_title("Sound vs Vibration Scatter")
plt.savefig('./image/sample_scatter.png')
plt.show()

# 例として vibration の rolling mean を異なる window で比較
# 色を固定して、わかりやすく再描画
import matplotlib.pyplot as plt

colors = {
    5: 'orange',
    20: 'red',
    50: 'purple',
    100: 'blue'
}

fig, ax = plt.subplots(figsize=(12, 6))

for w in colors:
    df[f'rolling_mean_{w}'] = df['vibration'].rolling(window=w).mean()
    ax.plot(df.index, df[f'rolling_mean_{w}'], label=f'Window {w}', color=colors[w], linewidth=2)

# 異常区間のハイライト
ax.axvspan(df.index[50], df.index[70], color='gray', alpha=0.2)
ax.set_title("Vibration Sensor - Rolling Mean (Fixed Colors)")
ax.set_ylabel("Rolling Mean")
ax.set_xlabel("Time")
ax.legend(title="Window Size")
plt.tight_layout()
plt.savefig('./image/sample_moving.png')
plt.show()